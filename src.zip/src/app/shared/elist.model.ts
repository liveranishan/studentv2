export class Elist {
    fName:string;
    cName:string;
    ename:number;
}
